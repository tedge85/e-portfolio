from __future__ import print_function, division

# Chapter 17 exercises

# As an exercise, rewrite time_to_int (from Section 16.4) as a method.
class Time:

    def __init__(self):
            
        self.hour = 0
        self.minute = 0
        self.second = 0
    
    def time_to_int(self):
        minutes = self.hour * 60 + self.minute
        seconds = minutes * 60 + self.second
        return seconds

# As an exercise, write an init method for the Point class that takes
# x and y as optional parameters and assigns them to the corresponding
# attributes.
class Point:
    
    def __init__(self, x=0, y=0):
        
        self.x = x
        self.y = y
        
    def __str__(self):
        return (f"x = {self.x}\ny = {self.y}")


    def __add__(self, other):
        if isinstance(other, Point):
        
            new_point = Point(x=self.x + other.x, y=self.y + other.y)
            
            return new_point
        
        elif isinstance(other, tuple):
            
            new_point = Point(x=self.x + other[0], y=self.y + other[1])
            
            return new_point
        
    def __radd__(self, other):
        
        return self.__add__(other)

point_one = Point(5, 10)


point_two = Point(4, 6)


print((2, 5) + point_one)