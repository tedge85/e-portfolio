from datetime import datetime
import copy

class Time:
    """Represents the time of day.attributes: hour, minute, second."""
    
time = Time()

time.hour = 11
time.minute = 59
time.second = 30

# As an exercise, write a function called print_time that takes a 
# Time object and prints it in the form hour:minute:second. Hint: 
# the format sequence '%.2d' prints an integer using at least two 
# digits, including a leading zero if necessary.
def print_time(time_object):

    print(f"{time_object.hour:02}:{time_object.minute:02}:{time_object.second:02}")


# Write a boolean function called is_after that takes two Time 
# objects, t1 and t2, and returns True if t1 follows t2 
# chronologically and False otherwise. Challenge: don’t use an if 
# statement.
def is_after(t1, t2):
    '''Return True if t1 time is later than t2 and False if not.'''   
    return t1.hour + t1.minute + t1.second > t2.hour + t2.minute + t2.second 
        

t1 = Time()
t1.hour = 12
t1.minute = 32
t1.second = 33

t2 = Time()
t2.hour = 18
t2.minute = 45
t2.second = 59

print(is_after(t1, t2))


# Below function taken from Downey(2015, p.157).
def increment(time, seconds):
    '''Modifier function.'''
    time.second += seconds
    
    if time.second >= 60: 
        full_minutes = seconds // 60                             
        time.second -= full_minutes * 60         
        time.minute += full_minutes
        
    if time.minute >= 60:
        full_hours = time.minute // 60        
        time.minute -= full_hours * 60
        time.hour += full_hours
        
    

increment(t1, 12000)

print_time(t1)

# As an exercise, write a “pure” version of increment that creates
# and returns a new Time object rather than modifying the parameter.
def pure_increment(time, seconds):
    '''Pure function, returning new time object.'''
    
    new_time_object = Time()
    new_time_object.second = 0
    new_time_object.minute = 0
    new_time_object.hour = 0
    
    new_time_object.second += seconds
    
    if new_time_object.second >= 60: 
        full_minutes = seconds // 60                             
        new_time_object.second -= full_minutes * 60         
        new_time_object.minute += full_minutes
        
    if new_time_object.minute >= 60:
        full_hours = new_time_object.minute // 60        
        new_time_object.minute -= full_hours * 60
        new_time_object.hour += full_hours
        
    return new_time_object

new_time_object = pure_increment(t1, 12005)

print_time(new_time_object)


#  The 3 functions below are provided in chapter 16 as a way
# of simplifying the above functions that compare time, by treating
# time as an integer (Downey, 2015, p.158).
def time_to_int(time):
    minutes = time.hour * 60 + time.minute
    seconds = minutes * 60 + time.second
    return seconds

    
def int_to_time(seconds):
    time = Time()
    minutes, time.second = divmod(seconds, 60)
    time.hour, time.minute = divmod(minutes, 60)
    return time


def add_time(t1, t2):
    seconds = time_to_int(t1) + time_to_int(t2)
    return int_to_time(seconds)

# My task - to rewrite increment using time_to_int and int_to_time.
def new_pure_increment(time, seconds):
    '''Modifier function.'''
    time_seconds = time_to_int(time)
    time_seconds += seconds
    time.seconds = time_seconds
    new_time_object = int_to_time(time_seconds)
    return new_time_object

t3 = new_pure_increment(t1, 12000)

print_time(t3)


## END OF CHAPTER EXERCISES ##

#Exercise 16.1. Write a function called mul_time that takes a Time object and 
# a number and returns a new Time object that contains the product of the 
# original Time and the number.

def mul_time(time, num):
    product = time_to_int(time) * num
    return int_to_time(product)


# 1. Use the datetime module to write a program that gets the current date 
# and prints the day of the week.
today = datetime.today()

print(today.strftime("%A"))



# 2. Write a program that takes a birthday as input and prints the 
# user’s age and the number of days, hours, minutes and seconds until
# their next birthday.
class Birthdate:
    year = 0
    month = 0
    day = 0

        
def calculate_age(birthday_object):
    '''Calculates age in years.'''

    today = datetime.today()
    age = int(today.year) - int(birthday_object.year)
    
    # Account for no birthday had this year.
    if (today.month, today.day) < (birthday_object.month, birthday_object.day):
        age -= 1
        
    return age


def calculate_time_until_bday(birthday_object):
    """Return time remaining before next birthday."""
        
    today = datetime.now()
        
    # If birthday not had yet this year, use this year; if it has, use 
    # next year.
    if (today.month, today.day) < (birthday_object.month, birthday_object.day):
        target_date = datetime(year=today.year, month=birthday_object.month, day=birthday_object.day)
    else:
        next_year = today.year + 1
        target_date = datetime(year=next_year, month=birthday_object.month, day=birthday_object.day)

    until_bday = target_date - today

    days = until_bday.days
    hours, remainder = divmod(until_bday.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    print(f"You have {days} days, {hours} hours, {minutes} minutes and {seconds} seconds remaining until your next birthday!")


birthday = Birthdate()

while True:
    
    try:
        birth_date = input("Please enter your date of birth (DD/MM/YYYY): ")    
        birthday.day = int(birth_date[0:2])
        birthday.month = int(birth_date[3:5])
        birthday.year = int(birth_date[6:10])
        print(f"You are {calculate_age(birthday)} years old!")
        print(f"You have {calculate_time_until_bday(birthday)} until your next birthday!")
        break
    
    except:
        ValueError
        print("!!You must use digits!!")

# 3. For two people born on different days, there is a day when one
# is twice as old as the other. That’s their Double Day. Write a 
# program that takes two birth dates and computes their Double Day
def has_not_had_birthday(birthday_object):

    today = datetime.now()
    
    if (birthday_object.month, birthday_object.day) >= (today.month, today.day):
    
        return True
    
    else:
        return False
    
        
def calculate_double_day(birthday_object_1, birthday_object_2):
    
    today = datetime.now()

    calculated_year = today.year - 1

    birthday_object_1 = copy.copy(birthday_object_1)
    
    birthday_object_1.age = calculate_age(birthday_object_1)

    birthday_object_2 = copy.copy(birthday_object_2)
            
    birthday_object_2.age = calculate_age(birthday_object_2)        

        
    # Add 1 to age if person has not yet had a birthday this year,
    # for ease of calculation. 
    if has_not_had_birthday(birthday_object_1):
        birthday_object_1.age + 1
        
        
    if has_not_had_birthday(birthday_object_2):
        birthday_object_2.age + 1
        

    if birthday_object_1.year > birthday_object_2.year:
        younger = birthday_object_1
        older = birthday_object_2
    else:
        younger = birthday_object_2
        older = birthday_object_1
    
    if birthday_object_1.month == birthday_object_2.month:
        if birthday_object_1.day < birthday_object_2.day:
            earlier_month_person  = birthday_object_1
            later_month_person = birthday_object_2
            
        else:
            earlier_month_person = birthday_object_2
            later_month_person  = birthday_object_1
        

    if birthday_object_1.month < birthday_object_2.month:
        earlier_month_person  = birthday_object_1
        later_month_person = birthday_object_2
        
    else:
        earlier_month_person = birthday_object_2
        later_month_person  = birthday_object_1
       
    
    age_diff = older.age - younger.age
    
    

    print(f"diff={age_diff}")
    print(f"older={older.age}") # this is wrong
    print(f"younger={younger.age}")

    
    if age_diff == 0:
        return print("These birthdates will never have a Double Day.")

    elif age_diff == younger.age:
        
        if younger.age * 2 == older.age:
            
            return print(f"The calculated Double Date is {later_month_person.day}/{later_month_person.month}/{today.year}")
        
        else:
            return print("These birthdates will never have a Double Day.")
        
    

    elif age_diff < younger.age:        
        
            while age_diff != younger.age:
            
                younger.age -= 1                
                older.age -= 1
                older.year -=1                
                calculated_year -= 1
                
            if younger.age * 2 == older.age and younger.month == later_month_person.month and has_not_had_birthday(younger):
                
                return print(f"The calculated Double Date is {later_month_person.day}/{later_month_person.month}/{calculated_year - 1}")

            else: 
                            
                    return print(f"The calculated Double Date is {later_month_person.day}/{later_month_person.month}/{calculated_year + 1}")
           
            
    elif age_diff > younger.age:
        
        while age_diff != younger.age:
            
                younger.age += 1
                younger.year += 1
                older.age += 1
                older.year +=1
                earlier_month_person.year += 1
                later_month_person.year += 1
                calculated_year += 1
        
                                        
        if younger.age * 2 == older.age and younger.month == later_month_person.month:
            
                return print(f"The calculated Double Date is {later_month_person.day}/{later_month_person.month}/{calculated_year + 1}")
            
        else:
                
            return print(f"The calculated Double Date is {earlier_month_person.day}/{earlier_month_person.month}/{calculated_year}")

birthday_1 = Birthdate()
birthday_1.day = 15
birthday_1.month = 2
birthday_1.year = 1951


birthday_2 = Birthdate()
birthday_2.day = 11
birthday_2.month = 2
birthday_2.year = 1985

calculate_double_day(birthday_1, birthday_2)

# References
# Downey, A.B. (2015) Think Python, 2nd Edition. O’Reilly Media, Inc. Available from https://greenteapress.com/thinkpython2/html/index.html [Accessed 9 November 2024].
