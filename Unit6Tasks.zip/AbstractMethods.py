from abc import abstractmethod

class Account:
    
    @abstractmethod
    def deposit_funds(self):
        pass
    
    @abstractmethod
    def withdraw_funds(self):
        pass
    
    @abstractmethod
    def view_funds(self):
        pass
    
class PersonalAccount(Account):
    
    def __init__(self, total_funds):
        self.total_funds = total_funds

    def deposit_funds(self, amount):
        '''Adds given funds to account total.'''
        
        self.total_funds += amount

    def withdraw_funds(self, amount):
        '''Subtracts given funds to account total.'''
        
        self.total_funds -= amount
        
    def view_funds(self):
        '''Returns current account total.'''
    
        return(f"£{self.total_funds}")
        
new_personal_account = PersonalAccount(125)

new_personal_account.deposit_funds(12)

new_personal_account.withdraw_funds(5)

print(new_personal_account.view_funds())
