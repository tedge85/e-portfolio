from __future__ import print_function, division
from tabulate import tabulate
from Card import Hand, Deck
import json

# This Python file contains some code examples from Downey (2015).

## EXERCISES ##
# The goal of these exercises is to estimate the probability of drawing these various hands.
# 1. Download the following files from https: // thinkpython. com/ code :
# Card.py : A complete version of the Card, Deck and Hand classes in this chapter.
# PokerHand.py : An incomplete implementation of a class that represents a poker hand, and
# some code that tests it.
# 2. If you run PokerHand.py, it deals seven 7-card poker hands and checks to see if any of them
# contains a flush. Read this code carefully before you go on.
# 3. Add methods to PokerHand.py named has_pair, has_twopair, etc. that return True or
# False according to whether or not the hand meets the relevant criteria. Your code should
# work correctly for “hands” that contain any number of cards (although 5 and 7 are the most
# common sizes).
# 4. Write a method named classify that figures out the highest-value classification for a hand
# and sets the label attribute accordingly. For example, a 7-card hand might contain a flush
# and a pair; it should be labeled “flush”.
# 5. When you are convinced that your classification methods are working, the next step is to estimate the probabilities of the various hands. Write a function in PokerHand.py that shuffles
# a deck of cards, divides it into hands, classifies the hands, and counts the number of times
# various classifications appear.
# 6. Print a table of the classifications and their probabilities. Run your program with larger and
# larger numbers of hands until the output values converge to a reasonable degree of accuracy. Compare y


class PokerHand(Hand):
    """Represents a poker hand."""


    def suit_hist(self):
        """Builds a histogram of the suits that appear in the hand.

        Stores the result in attribute suits.
        """
        self.suits = {}
        for card in self.cards:
            self.suits[card.suit] = self.suits.get(card.suit, 0) + 1
            
    def rank_hist(self):
        """Builds a histogram of the ranks that appear in the hand.

        Stores the result in attribute ranks.
        """
        self.ranks = {}
        for card in self.cards:
            self.ranks[card.rank] = self.ranks.get(card.rank, 0) + 1

    def has_flush(self):
        """Returns True if the hand has a flush, False otherwise.
      
        Note that this works correctly for hands with more than 5 cards.
        """
        self.suit_hist()
        for val in self.suits.values():
            if val >= 5:
                return True
        return False
    
    def has_pair(self):
        """Returns True if the hand has a pair, False otherwise."""

        self.rank_hist()
        for val in self.ranks.values():
            if val == 2:
                return True
        return False
    
    def has_twopair(self):
        """Returns True if the hand has two sets of pairs, False otherwise."""
        pairs_list = []

        self.rank_hist()
        for val in self.ranks.values():
            if val == 2:
                pairs_list.append(val)
        
        if len(pairs_list) == 2:
            return True
        return False
    
    def has_threeofakind(self):
        """Returns True if the hand has three of the same rank, False 
        otherwise."""
        pairs_list = []

        self.rank_hist()
        for val in self.ranks.values():
            if val == 3:
                return True
        return False
    
    def has_straight(self):
        """Returns True if the hand has five consecutive ranks, False 
        otherwise."""
        key_list = []

        self.rank_hist()
        for key, val in self.ranks.items():
            if val >= 1:
                key_list.append(key)
            

        if set([1, 2, 3, 4, 5]).issubset(set(key_list)):
            return True
        elif set([2, 3, 4, 5, 6]).issubset(set(key_list)):
            return True
        elif set([3, 4, 5, 6, 7]).issubset(set(key_list)):
            return True
        elif set([4, 5, 6, 7, 8]).issubset(set(key_list)):
            return True
        elif set([5, 6, 7, 8, 9]).issubset(set(key_list)):
            return True
        elif set([6, 7, 8, 9, 10]).issubset(set(key_list)):
            return True
        elif set([7, 8, 9, 10, 11]).issubset(set(key_list)):
            return True
        elif set([8, 9, 10, 11, 12]).issubset(set(key_list)):
            return True
        elif set([9, 10, 11, 12, 13]).issubset(set(key_list)):
            return True
        elif set([10, 11, 12, 13, 0]).issubset(set(key_list)):
            return True
        else:
            return False
        
    def has_fullhouse(self):
        """Returns True if three cards with one rank, two cards with another, 
        False otherwise."""
            
        pairs_list = []
        threes_list = []

        self.rank_hist()
        for val in self.ranks.values():
            if val == 2:
                pairs_list.append(val)
            elif val == 3:
                threes_list.append(val)
                

        if len(pairs_list) == 1 and len(threes_list) == 1:
            return True
        return False
        
    def has_fourofakind(self):
        """Returns True if the hand has three of the same rank, False 
        otherwise."""
        pairs_list = []

        self.rank_hist()
        for val in self.ranks.values():
            if val == 4:
                return True
        return False
    
    def has_straightflush(self):
        """Returens True if five cards with ranks in sequence and with the,
        same suit, False otherwise."""
       
        if self.has_flush() and self.has_straight():
            return True
        return False
    
    
    def classify(self):
        """Figures out the highest-value classification for a hand
        and sets the label attribute accordingly."""
        if self.has_straightflush():
            self.label = "straight flush"
        elif self.has_fourofakind():
            self.label = "four of a kind"
        elif self.has_fullhouse():
            self.label = "full house"
        elif self.has_flush():
            self.label = "flush"
        elif self.has_straight():
            self.label = "straight"
        elif self.has_threeofakind():
            self.label = "three of a kind"
        elif self.has_twopair():
            self.label = "two pair"
        elif self.has_pair():
            self.label = "pair"
        else:
            self.label = "high card"

def load_dict(dict_name):
    '''Loads json files - for users or lessons - into dictionaries.'''
    try:
        with open(f"{dict_name}.json", "r") as f:
            return json.load(f)
    # create an empty list if list.json has not yet been created.
    except FileNotFoundError:
        return {}   


def save_dict(json_file_name, dict_name):
    '''Saves user or lesson dictionaries into json files.'''

    with open(f"{json_file_name}.json", "w") as f:
        json.dump(dict_name, f, indent=4)
        
if __name__ == '__main__':
    # make a deck
    deck = Deck()
    deck.shuffle()

    # deal the cards and classify the hands
    hand_hist = load_dict("hand_hist")
    for i in range(7):
        hand = PokerHand()
        deck.move_cards(hand, 7)
        hand.sort()        
        hand.classify()
                            
        print(hand)        
        print(f"Pair? {hand.has_pair()}")
        print(f"Two-pair? {hand.has_twopair()}")
        print(f"Three of a kind? {hand.has_threeofakind()}")
        print(f"Straight? {hand.has_straight()}")
        print(f"Flush? {hand.has_flush()}")
        print(f"Full house? {hand.has_fullhouse()}")
        print(f"Four of a kind? {hand.has_fourofakind()}")
        print(f"Straight flush? {hand.has_straightflush()}")        
        print('')       
        
    if hand_hist[hand.label] > 0:
            hand_hist[hand.label] += 1
    else:
        hand_hist[hand.label] = 1
    
    hand_hist['hands dealt'] += 1

    save_dict("hand_hist", hand_hist)
    
    hand_hist = load_dict("hand_hist")
    
    print(hand.label)
    print(hand_hist)

    # Define the table data 
    headers = ["Hand", "Probability"] 
    
    data = [ 
           ['high card', f"{hand_hist['high card'] / hand_hist['hands dealt']}'%'"], 
           ['pair', f"{hand_hist['pair'] / hand_hist['hands dealt']}'%'"],
           ['two pair', f"{hand_hist['two pair'] / hand_hist['hands dealt']}'%'"],
           ['three of a kind', f"{hand_hist['three of a kind'] / hand_hist['hands dealt']}'%'"],
           ['straight', f"{hand_hist['straight'] / hand_hist['hands dealt']}'%'"],
           ['flush', f"{hand_hist['flush'] / hand_hist['hands dealt']}'%'"],
           ['full house', f"{hand_hist['full house'] / hand_hist['hands dealt']}'%'"],
           ['four of a kind', f"{hand_hist['four of a kind'] / hand_hist['hands dealt']}'%'"],
           ['straight flush', f"{hand_hist['straight flush'] / hand_hist['hands dealt']}'%'"]           
           ] 
    
    # Print the table:     
    print(tabulate(data, headers, tablefmt="grid"))
    
# References
# Downey, A.B. (2015) Think Python, 2nd Edition. O’Reilly Media, Inc. Available from https://greenteapress.com/thinkpython2/html/index.html [Accessed 9 November 2024].