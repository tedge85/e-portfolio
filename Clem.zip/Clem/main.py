import openai
import random
from collections import deque
from clem import (
    Head, 
    EyeLids, 
    Eyebrows, 
    Mouth, 
    Arms, 
    Hands, 
    Torso, 
    PhysicalInteraction, 
    ExpressionSensor, 
    PostureSensor,
    PitchSensor, 
    RobotEmotion, 
    SemanticSearch,
    UserEmotion, 
    Dialogue    
)

API_KEY = open("API_KEY.txt", "r").read() # Read OpenAI key from text file.

# OpenAI key variable used to access OpenAI API (OpenAI, 2024).
openai.api_key = API_KEY 

## Instantiating objects ##

# Training the ChatGPT LLM on the responses tone and typical content.
# and using this initial input to instantiate the Dialogue object, 
# ready to receive user input to respond to.
description_of_carer_role = (
    "You are a caring social assistant who listens to elderly people and" 
    " responds so that they feel heard and understood. You may give advice" 
    " occasionally."
)

dialogue = Dialogue(chat_log_history = [
                    {"role": "system",
                    "content": description_of_carer_role}
                    ])        

# Instantiating the user_emotion object that represents the user's
# emotions.
user_emotion = UserEmotion() 

# Instantiating remaining objects that make up the HR.
clem_emotion = RobotEmotion()

head = Head()

eyelids = EyeLids()

eyebrows = Eyebrows()

mouth = Mouth()

arms = Arms()

hands = Hands()

torso = Torso()

phys_interaction = PhysicalInteraction()

semantic_search = SemanticSearch()

expression_sensor = ExpressionSensor()

posture_sensor = PostureSensor()

pitch_sensor = PitchSensor()


# CLI logic
if __name__ == "__main__":                
    
    user_name = input(
        "Please enter your first name or the name you would like me"
        " to call you: "
    ) 

    # Simulate getting baseline assessment of user's pitch so that 
    # this can be used to assess subsequent emotion in user's voice. 
    rand_num = random.randint(85, 255)
    pitch_baseline = pitch_sensor._baseline_assess_natural_pitch(rand_num)

    # Personalised introductory message:
    print("Hi, " + user_name + ". What would you like to chat about" 
        " today?\n"
    )

    # Main conversation loop.
    while True: 

        # Store this string as option so it can be repeated within
        # interface.
        option = "Type 'y' to confirm or any other key to reject: "               
        
        # Queue used to store first and second user inputs to pass 
        # to dialogue object.
        messages_to_reply_to = deque([]) 
        
        # Ensure str format so it is accepted by ChatGPT API methods.
        first_user_input = str(input(">> ")) 
            
        messages_to_reply_to.append(first_user_input)            
        
        # Get rid of commas in user's speech input, so that it can be
        # correctly formatted as a list of strings.
        input_without_commas = first_user_input.replace(",","")
        input_as_list = input_without_commas.split()

        # Read user emotions using language semantic analysis.
        lang_reading = semantic_search._emotions_match(input_as_list)

        # Read user emotions using semantic analysis, expression 
        # sensor, posture sensor and pitch sensor.                
        expr_reading = expression_sensor._sense_facial_expression()

        pos_reading = posture_sensor._match_posture_to_emotion()
                    
        # Pitch emotion reading.
        p_r = pitch_sensor._assess_pitch(pitch_baseline)                         

        u_e = user_emotion

        # Ascertain whether graded emotions in language analysis is 
        # mainly neutral, positive or negative by converting to emotion
        # matches to graded emotions before sorting neutral, positive 
        # and negative grades into their respective lists. The list 
        # sizes will later be compared so that largely neutral language
        # content can bypass other sensors.  
        lang_ems = u_e._convert_emotion_list_to_graded_emotion_list(
            lang_reading
        ) 
                       
        neutral_lang = [] 
        pos_lang = []
        neg_lang = []
        
        for emotion in lang_ems:
            if emotion == "neutral":
                neutral_lang.append(emotion)
            elif "positive" in emotion:
                pos_lang.append(emotion)
            else:
                neg_lang.append(emotion)
            
        neu_len = len(neutral_lang) 
        pos_len = len(pos_lang)
        neg_len = len(neg_lang)                

        # Compare list sizes to ascertain if predominant emotion 
        # detected in semantic analysis is neutral or if no emotion 
        # is detected. If so, bypass mean emotion calculation based
        # that factors in other sensor readings, as simulated sensors 
        # could skew mean calculation when language is largely neutral.
        if neu_len > pos_len and neu_len > neg_len:                
            
            u_e._convert_to_graded_emotions(input_as_list,"OK","OK")

            u_e._convert_nonpitch_emotions_to_graded_emotion_scores()

        elif neu_len == 0 and pos_len == 0 and neg_len == 0:
            
            u_e._convert_to_graded_emotions(input_as_list,"OK","OK")
            
            u_e._convert_nonpitch_emotions_to_graded_emotion_scores()
            
        else:
            # If predmonant emotion is not 'neutral', use simulated 
            # sensor data to contribute to graded emotion score.                
            u_e._convert_to_graded_emotions(lang_reading,expr_reading,pos_reading)

            u_e._convert_nonpitch_emotions_to_graded_emotion_scores()

            u_e._convert_pitch_emotions_to_graded_emotion_scores(pitch_baseline,p_r)

        # Get average emotion score.
        mean_em_score = user_emotion.calculate_mean_user_emotions_score()

        # Use average emotional score to help Clem decide an appropriate
        # positive emotional response.
        clem_em_resp = clem_emotion.decide_robot_emotion(mean_em_score)

        # Input Clem's appropriate emotional response into all 
        # body parts' listening gesture methods.
        head.listening_gesture(clem_em_resp)
        eyelids.listening_gesture(clem_em_resp)
        eyebrows.listening_gesture(clem_em_resp)
        mouth.listening_gesture(clem_em_resp)
        torso.listening_gesture(clem_em_resp)

        # Record user's overall mean score in 
        # user_emotion.user_emotion_history queue.
        user_emotion._record_final_user_emotion_score(mean_em_score)

        # Reset body parts' x, y and z positions.
        head._return_to_neutral_positon()
        eyelids._return_to_neutral_positon()
        eyebrows._return_to_neutral_positon()
        mouth._return_to_neutral_positon()
        torso._return_to_neutral_positon() 

        # Check whether or not user wants to chat more.
        dialogue._print_end_of_speech_prompt()

        user_choice = input(">> ")
        
        # Process response to see if 'g' was given to signify that 
        # user wants to say goodbye.
        if dialogue._user_wants_to_say_goodbye(user_choice):
            
            premature_goodbye_msg = (
            "Sorry you didn't feel like chatting today;"
            " maybe next time."
        )
            # Don't print a personalised goodbye message if user says
            # goodbye after first input i.e. they have no emotion 
            # score history.            
            if len(user_emotion.user_emotion_score_history) == 0:
                                
                print(premature_goodbye_msg)

                exit()
            
            # If user is saying goodbye after having chatted, give
            # personalised goodbye message that comments on emotions
            # read throughout conversation then suggests a physical
            # interaction based on these.
            else:

                initial_em = user_emotion.user_emotion_score_history[0]

                final_em = user_emotion.return_most_recent_user_emotion_grade()            
                
                phys_resp = clem_emotion.suggest_physical_interaction(final_em)                                 
                
                print(dialogue._say_goodbye(initial_em, final_em))

                print(f"Would you like a {phys_resp}?")
                
                user_choice = input(option)                
                    
                # If user wants physical interaction, initiate 
                # depending on final emotion.
                if dialogue._user_confirms_choice(user_choice):

                    # Simulate user force applied to physical 
                    # interaction, to be used in physical
                    # interaction methods.
                    user_force = random.randint(0,99)                                         

                    # Argument to be used for body parts that perform 
                    # physical interaction, ensuring safe force 
                    # applied by Clem.
                    clem_force = phys_interaction.apply_safe_robot_force
                    
                    # Use suggested appropriate physical response 
                    # to match these to methods that move body parts
                    # to complete these physical responses.
                    if phys_resp == "hand squeeze":

                            # Arms control key movements and initialise 
                            # subsequent hand movement. 
                            hand_response = hands.squeeze_hand
                            arms.squeeze_hand(hand_response,clem_force,user_force)                                      
                            exit()

                    elif phys_resp == "hand shake":

                        hand_response = hands.shake_hand
                        arms.shake_hand(hand_response,clem_force,user_force)
                        exit()

                    elif phys_resp == "high five":
                        
                        hand_response = hands.give_high_five
                        arms.give_high_five(hand_response,clem_force,user_force)
                        exit()

                    elif phys_resp == "hug":

                        hand_response = hands.hug
                        arms.hug(hand_response,clem_force,user_force)                        
                        torso.hug(clem_force,user_force)
                        exit()

                    elif phys_resp == "big hug":

                        hand_response = hands.hug
                        arms.big_hug(hand_response,clem_force,user_force)                        
                        torso.big_hug(clem_force,user_force)
                        exit()

                    else:
                        print("Hope to speak again soon :-)")
                        exit()
                
                # Say final goodbye instead of pyhsical interaction
                # if user confirms they do not want the physical 
                # interaction. 
                else:
                    print("\nGoodbye :-)\n")
                    exit()
                    
        # Check user's response to end of speech prompt. 
        elif dialogue._user_confirms_choice(user_choice):  
                        
            second_user_input = str(input("\nTell me more: "))
            
            messages_to_reply_to.append(second_user_input)            


            # Get rid of commas in user's speech input, so that it can be
            # correctly formatted as a list of strings.
            input_without_commas = first_user_input.replace(",","")
            input_as_list = input_without_commas.split()

            # Read user emotions using language semantic analysis.
            lang_reading = semantic_search._emotions_match(input_as_list)

            # Read user emotions using semantic analysis, expression 
            # sensor, posture sensor and pitch sensor.                
            expr_reading = expression_sensor._sense_facial_expression()

            pos_reading = posture_sensor._match_posture_to_emotion()
                        
            # Pitch emotion reading.
            p_r = pitch_sensor._assess_pitch(pitch_baseline)                         

            u_e = user_emotion

            # Ascertain whether graded emotions in language analysis is 
            # mainly neutral, positive or negative by converting to emotion
            # matches to graded emotions before sorting neutral, positive 
            # and negative grades into their respective lists. The list 
            # sizes will later be compared so that largely neutral language
            # content can bypass other sensors.  
            lang_ems = u_e._convert_emotion_list_to_graded_emotion_list(
                lang_reading
            ) 
                        
            neutral_lang = [] 
            pos_lang = []
            neg_lang = []
            
            for emotion in lang_ems:
                if emotion == "neutral":
                    neutral_lang.append(emotion)
                elif "positive" in emotion:
                    pos_lang.append(emotion)
                else:
                    neg_lang.append(emotion)
                            
            neu_len = len(neutral_lang) 
            pos_len = len(pos_lang)
            neg_len = len(neg_lang)
            
            # Compare list sizes to ascertain if predominant emotion 
            # detected in semantic analysis is neutral or if no emotion 
            # is detected. If so, bypass mean emotion calculation based
            # that factors in other sensor readings, as simulated sensors 
            # could skew mean calculation when language is largely neutral.
            if neu_len > pos_len and neu_len > neg_len:                
                
                u_e._convert_to_graded_emotions(input_as_list,"OK","OK")
                
                u_e._convert_nonpitch_emotions_to_graded_emotion_scores()
                
                # Get average emotion score.
                mean_em_score = user_emotion.calculate_mean_user_emotions_score()                
                
                # Record user's overall mean score in 
                # user_emotion.user_emotion_history queue.
                user_emotion._record_final_user_emotion_score(mean_em_score) 

            elif neu_len == 0 and pos_len == 0 and neg_len == 0:
                
                u_e._convert_to_graded_emotions(input_as_list,"OK","OK")
                
                u_e._convert_nonpitch_emotions_to_graded_emotion_scores()

                # Get average emotion score.
                mean_em_score = user_emotion.calculate_mean_user_emotions_score()                
                
                # Record user's overall mean score in 
                # user_emotion.user_emotion_history queue.
                user_emotion._record_final_user_emotion_score(mean_em_score) 
                
            else:
                # If predmonant emotion is not 'neutral', use simulated 
                # sensor data to contribute to graded emotion score.                
                u_e._convert_to_graded_emotions(lang_reading,expr_reading,pos_reading)

                u_e._convert_nonpitch_emotions_to_graded_emotion_scores()
                
                p_b = pitch_baseline

                u_e._convert_pitch_emotions_to_graded_emotion_scores(p_b,p_r)

                # Get average emotion score.
                mean_em_score = user_emotion.calculate_mean_user_emotions_score()                
                
                # Record user's overall mean score in 
                # user_emotion.user_emotion_history queue.
                user_emotion._record_final_user_emotion_score(mean_em_score) 
            

            # Use average emotional score to help Clem decide an appropriate
            # positive emotional response.
            clem_em_resp = clem_emotion.decide_robot_emotion(mean_em_score)

            # Input Clem's appropriate emotional response into all 
            # body parts' listening gesture methods.
            head.listening_gesture(clem_em_resp)
            eyelids.listening_gesture(clem_em_resp)
            eyebrows.listening_gesture(clem_em_resp)
            mouth.listening_gesture(clem_em_resp)
            torso.listening_gesture(clem_em_resp)            

            # Reset body parts' x, y and z positions.
            head._return_to_neutral_positon()
            eyelids._return_to_neutral_positon()
            eyebrows._return_to_neutral_positon()
            mouth._return_to_neutral_positon()
            torso._return_to_neutral_positon() 

            # Record user's overall mean score in 
            # user_emotion.user_emotion_history queue.
            user_emotion._record_final_user_emotion_score(mean_em_score)

            # Reset body parts' x, y and z positions.
            head._return_to_neutral_positon()
            eyelids._return_to_neutral_positon()
            eyebrows._return_to_neutral_positon()
            mouth._return_to_neutral_positon()
            torso._return_to_neutral_positon()                 
                
            # Reset temp emotion storage.
            user_emotion._reset_graded_emotions()

            user_emotion._reset_emotions_scores()

        else:
            # '.' entered if no second input desitred so as to avoid
            # error with trying to pop from empty dequeue.
            second_user_input = "."                     
            messages_to_reply_to.append(second_user_input)
        
        
        # Messages appended to messages_to_reply_to added to 
        # speech variable in chronological order.
        # Format user's inputted speech so that it can be processed 
        # by ChatGPT API within dialogue object.                                                  
        speech = messages_to_reply_to.popleft() + messages_to_reply_to.pop()
            
        updated_chat_log = {
            "role": "user", 
            "content": speech 
        }
        
        # HR contextual response, using updated_chat_log record of 
        # speech for reference. 
        print(dialogue.respond(updated_chat_log))
