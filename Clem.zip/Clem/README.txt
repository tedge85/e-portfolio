CLEM is a CLI program that simulates the functionality of CLEM - a social humanoid robot for the elderly.

FEATURES
-------------------
-------------------
- ChatGPT-powered contextual speech, using a carer's tone;
- User's emotions detected through semantic analysis and simulated sensors for facial expression, posture, and pitch of voice;
- Contextual body part movement - based on user's emotions - shows that CLEM is listening intently;
- Simulated contextual physical interactions based on user’s emotions;
- Responsive goodbye messages, based on the user's emotional journey during the conversation.

REQUIREMENTS
-------------------
-------------------
annotated-types==0.7.0
anyio==4.7.0
certifi==2024.12.14
colorama==0.4.6
distro==1.9.0
h11==0.14.0
httpcore==1.0.7
httpx==0.28.1
idna==3.10
jiter==0.8.2
keyboard==0.13.5
openai==1.57.4
pydantic==2.10.3
pydantic_core==2.27.1
pynput==1.7.7
six==1.17.0
sniffio==1.3.1
tqdm==4.67.1
typing_extensions==4.12.2
windows-curses==2.4.0

USAGE INSTRUCTIONS
-------------------
-------------------
- Purchase a ChatGPT API key and save this in a .txt file under the name 'API_KEY';
- Navigate to the 'Clem' root directory in your chosen IDE's terminal;
- Activate the virtual environment with ‘env/Scripts/Activate.ps1’;
- Open the main.py file;
- Type 'Python "main.py" into your terminal and press enter;
- Type your name at the first prompt to receive a personalised message;
- Chat to CLEM using text input;
- Text will print to the terminal to tell you what listening movements CLEM is making in response to your first and second inputs in each round of inputs;
- Add further text input by confirming with 'y' or press any other key to receive an immediate response; 
- Repeat the above until you wish to end the conversation by pressing 'g' when prompted;
- At this point CLEM will give you a message to comment on your emotional journey from the start to the end of the conversation;
- Confirm that you would like to receive a physical interaction with ‘y’ or skip this by pressing any other key to receive a final ‘goodbye 😊’.

REFLECTIONS
-------------------
-------------------

When originally designing CLEM’s software, the aim was to achieve a modular, object oriented design in order to make the code reusable, easy to read, test and debug (Gamma, 1995). When writing the code, it was found that improvements could be made to better achieve these goals. Additional changes were made to adhere more closely to PEP-8 (Alchin, 2010) guidelines to achieve greater code readability. I have discussed the main changes within this reflection.

One of the first decisions made to make the code more modular was to split up the PhysicalInteraction.physical_interaction() method into individual action methods e.g. hug(), shake_hands(), that were assigned to each body part class. This decision sought to better separate responsibility, as well as decrease the cyclomatic complexity of the program as the original method included many branching logic statements that would have produced a high cyclomatic complexity rating (Ebert et al, 2016; Gamma, 1995). 

To further decrease cyclomatic complexity, the UserEmotion.decide_user_emotion() was also found to contain too many ‘if’ statements, and so this was replaced with several methods and attributes that were employed to process the emotion data. Here, a key attribute is the UserEmotion.user_emotion_choices dictionary, which is used to link emotion string values to a key that grades each emotion (judging it to be a positive, negative or neutral emotion) and its intensity (negative_1-negative_3, neutral, positive_1-positive_3; the higher the number, the more intense the emotion). These strings are later converted to a corresponding integer – an addition that proved extremely useful for comparison logic within methods such as Dialogue.say_goodbye() which prints a response that comments on positive, negative, or a lack of emotional variance between the start and end of the conversation. 

In a further attempt to achieve more modularity, the decision was made to make a separate SemanticSearch class, so as to take the responsibility of detecting user emotion in speech input away from the Dialogue class. Similarly, a PostureSensor class was created to deal with emotion detection based on posture, rather than having the ExpressionSensor class do this. 

This process has taught me that, at my current level as a novice programmer, many design decisions around modularity have come to me during the design implementation process, where the logistics of implementing code is more clearly realised.

References
-------------------
Alchin, M. (2010) 'PEP 8 Style Guide for Python', in: Alchin, M. Pro Python. United States: Apress L. P.

Ebert, C., Cain, J., Antoniol, G., Counsell, S. & Laplante, P. (2016).  Cyclomatic Complexity. IEEE Software 33(6): 27-29. DOI: 10.1109/MS.2016.147 

Gamma, E. (1995) Design patterns: elements of reusable object-oriented software. Reading, Mass: Addison-Wesley.

OpenAI (2024) API Reference. Available from: https://platform.openai.com/docs/api-reference/introduction [Accessed 30th November 2024].
