import openai
import random
import difflib
from abc import abstractmethod

API_KEY = open("API_KEY.txt", "r").read() # Read OpenAI key from text file.

# OpenAI key variable used to access OpenAI API (OpenAI, 2024).
openai.api_key = API_KEY  


class BodyParts:
    """
    An abstract class to represent the humanoid robot's (HR) 
    bodyparts.

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    listening_gesture(current_robot_emotion): 
        Abstract method to be implemented by subclasses, representing
        a movement to show that the HR is listening.

    """

    def __init__(self):
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """
        self.current_xposition = 0 
        self.current_yposition = 0
        self.current_zposition = 0


    @abstractmethod
    def listening_gesture(self, current_robot_emotion):
        """This abstract method will include logic to move body parts"""
        
        pass

    @abstractmethod
    def _return_to_neutral_positon(self):
        """Return all body part coordinates to 0."""

        self.current_xposition = 0
        self.current_xposition = 0
        self.current_zposition = 0


class Head(BodyParts):
    """
    A subclass to represent the humanoid robot's Head. 

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    listening_gesture(current_robot_emotion): 
        Method to show that the HR is listening, implementing a 
        nuanced nod that moves the x, y, and/or z axis position 
        of the bodypart.

    """

    # Inherit current_xposition, current_yposition, 
    # current_zposition.
    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """

    def listening_gesture(self, current_robot_emotion):
        """
        Move head to signify listening, expressing emotion.
        
        Args:
            current_robot_emotion (str): graded emotion calculated
            from robot class in response to user's emotion reading.  

        Return: None

        """
                
        if current_robot_emotion == "sympathetic_1":
            
            self.current_yposition += 20

            for i in range(6):
                self.current_zposition += 10
                self.current_zposition -= 10                
                
                
            print("*Clem nods slowly*") 
        
        elif current_robot_emotion == "sympathetic_2":

            self.current_yposition += 10

            for i in range(8):
                self.current_zposition += 5
                self.current_zposition -= 5                                
                
            print("*Clem nods delicately*")

        elif current_robot_emotion == "sympathetic_3":
            
            self.current_yposition += 30
            
            for i in range(6):
                self.current_zposition += 10
                self.current_zposition -= 10                
                
            print("*Clem nods sympathetically*")

        elif current_robot_emotion == "pleased_2":
            
            self.current_yposition += 40

            for i in range(6):
                self.current_zposition += 30
                self.current_zposition -= 30                                
                
            print("*Clem nods quickly*")

        elif current_robot_emotion == "pleased_3":
            
            self.current_yposition += 20

            for i in range(6):
                self.current_zposition += 5                
                self.current_zposition -= 5
                
            print("*Clem nods encouragingly*")

        else:
            pass # No head movement for pleased_1 or neuutral emotions.


    def _return_to_neutral_positon(self):
        """Return head's x, y and z coordinates to 0."""
        
        super()._return_to_neutral_positon()


class EyeLids(BodyParts):
    """
    A subclass to represent the humanoid robot's Eyelids.     

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    listening_gesture(current_robot_emotion): 
        Method to show that the HR is listening, implementing a 
        nuanced squint that moves the x, y, and/or z axis position 
        of the bodypart.

    """


    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """

    def listening_gesture(self, current_robot_emotion):
        """
        Move eyelids to signify listening, expressing emotion.
        
        Args:
            current_robot_emotion (str): graded emotion calculated
            from robot class in response to user's emotion reading.

        Return: None  

        """                        
        
        # Condition for all pleased emotion responses.
        if current_robot_emotion[0] == "p": 
            
            self.current_xposition += 15                
            self.current_yposition -= 10            
                
            print("*Clem's eyes widen*")

        # Condition for all sympathetic emotions responses.                         
        elif current_robot_emotion[0] == "s":
            self.current_xposition += 10                
            self.current_yposition -= 5            
                
            print("*Clem squints slightly*")
        # Do nothing if emotion response is neutral.
        else:
            pass


    def _return_to_neutral_positon(self):
        """Return eyelids' x, y and z coordinates to 0."""

        super()._return_to_neutral_positon()


class Eyebrows(BodyParts):
    """
    A subclass to represent the humanoid robot's Eyebrows. 

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    listening_gesture(current_robot_emotion): 
        Method to show that the HR is listening, implementing a 
        nuanced raise of the eybrows that moves the x, y, and/or 
        z axis position of the bodypart.

    """


    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """

    def listening_gesture(self, current_robot_emotion):
        """
        Move eyebrows to signify listening, expressing emotion.
        
        Args:
            current_robot_emotion (str): graded emotion calculated
            from robot class in response to user's emotion reading.

        Return: None  

        """                        
        
        c_r_e = current_robot_emotion 
        
        # Condition for all sympathetic emotions or 
        # extreme positive emotion.
        if c_r_e[0] == "s" or c_r_e == "pleased_3": 
            
            self.current_xposition += 15                                        
                
            print("*Clem raises her eyebrows*")
                         
        else:
            pass # No eyebrow movement for other emotions.

    def _return_to_neutral_positon(self):
        """Return eyebrow's x, y and z coordinates to 0."""

        super()._return_to_neutral_positon()


class Mouth(BodyParts): 
    """
    A subclass to represent the humanoid robot's Mouth. 

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    listening_gesture(current_robot_emotion): 
        Method to show that the HR is listening, implementing a 
        nuanced smile that moves the x, y, and/or z axis position 
        of the bodypart.

    """


    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """
    
    def listening_gesture(self, current_robot_emotion):
        """
        Move mouth to signify listening, expressing emotion.
        
        Args:
            current_robot_emotion (str): graded emotion calculated
            from robot class in response to user's emotion reading.

        Return: None  

        """                        
                
        c_r_e = current_robot_emotion
        
        if c_r_e == "neutral": 
            
            self.current_xposition += 5                                        
                
            print("*Clem smiles*")

        elif c_r_e == "pleased_1": 
            
            self.current_xposition += 10                                        
                
            print("*Clem smiles brightly*")

        elif c_r_e == "pleased_2" or c_r_e == "pleased_3": 
            
            self.current_xposition += 15
            self.current_yposition += 5                                        
                
            print("*Clem smiles broadly*")

        # Condition for all sympathetic cases.
        else:
            self.current_xposition += 7                                        
                
            print("*Clem smiles sympathetically*")


    def _return_to_neutral_positon(self):
        """Return mouth's x, y and z coordinates to 0."""

        super()._return_to_neutral_positon()
        

class Arms(BodyParts):
    """
    A subclass to represent the humanoid robot's Arms. 

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    hug(hands_hug_method, safe_robot_force_method, user_force): 
        Method to move the position of the arms along the x and 
        y axes in order to simulate a hugging action. Calls 
        corresponding hand movement method. Calls PhysicalInteraction 
        method to coordinate force applied by HR.

    big_hug(hands_hug_method, safe_robot_force_method, 
        user_force):
        Method to move the position of the arms along the x and 
        y axes in order to simulate a more intense hugging action.
        Calls corresponding hand movement method. Calls 
        PhysicalInteraction method to coordinate force applied by HR.

    squeeze_hand(hands_squeeze_method, safe_robot_force_method,
        user_force):
        Method to move the position of the arms along the x and 
        y axes in order to simulate a hand squeeze action.
        Calls corresponding hand movement method. Calls 
        PhysicalInteraction method to coordinate force applied by HR.

    shake_hand(hands_shake_method, safe_robot_force_method, 
        user_force):
        Method to move the position of the arms along the x and 
        y axes in order to simulate a hand shake action.
        Calls corresponding hand movement method. Calls 
        PhysicalInteraction method to coordinate force applied by HR.

    give_high_five(hands_hfive_method, safe_robot_force_method,
        user_force):
        Method to move the position of the arms along the x and 
        y axes in order to simulate a high-five action.
        Calls corresponding hand movement method. Calls 
        PhysicalInteraction method to coordinate force applied by HR.

    """

    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """

    def hug(self, hands_hug_method, 
            safe_robot_force_method, user_force):
        """
        Move the x and y positions & coordinate hands to give user a hug.

        Args:
            hands_hug_method (str): name of hand hug method to call
            with user_force as argument.
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """

        self.current_xposition += 30
        self.current_yposition += 30

        # Call method to move hands once arms in # position.    
        hands_hug_method(safe_robot_force_method, user_force) 

        # Call method to safely apply robot force in interaction.    
        safe_robot_force_method(user_force)
            
        print("*Clem gives you a hug*")

    
    def big_hug(self, hands_hug_method, 
            safe_robot_force_method, user_force):
        """
        Move the x and y positions & coordinate hands to give big hug.

        Args:
            hands_hug_method (str): name of hand hug method to call
            with user_force as argument.
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """
        
        self.current_xposition += 50
        self.current_yposition += 30
        
        # Call method to move hands once arms in # position.
        hands_hug_method(safe_robot_force_method, user_force)  
        
        # Call method to safely apply robot force in interaction.                                         
        safe_robot_force_method(user_force) 
        
        print("*Clem gives you a big hug*")


    def squeeze_hand(self, hands_squeeze_method, 
            safe_robot_force_method, user_force):
        """
        Move the x & coordinate hands to squeeze user's hand.

        Args:
            hands_squeeze_method (str): name of hand hug method to call
            with user_force as argument.
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """
        
        self.current_xposition += 15
            
        hands_squeeze_method(safe_robot_force_method, user_force) 
            
        safe_robot_force_method(user_force)
            
        print("*Clem squeezes your hand*")
    

    def shake_hand(self, hands_shake_method, 
            safe_robot_force_method, user_force):
        """
        Move the x position & coordinate hands to give big hug.

        Args:
            hands_shake_method (str): name of hand hug method to call
            with user_force as argument.
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """

        for i in range(4): # Shake hands with 4 shakes.
                self.current_xposition += 15
                safe_robot_force_method(user_force)
                hands_shake_method(safe_robot_force_method, user_force) 
                safe_robot_force_method(user_force)
                self.current_xposition -= 15
                i += 1
                        
        print("*Clem shakes your hand*")

    
    def give_high_five(self, hands_hfive_method, 
            safe_robot_force_method, user_force):
        """
        Move the x and y positions & coordinate hands to give high-five.

        Args:
            hands_hfive_method (str): name of hand hug method to call
            with user_force as argument.
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """

        self.current_xposition += 80
        self.current_yposition += 30
            
        hands_hfive_method(safe_robot_force_method, user_force) 
            
        safe_robot_force_method(user_force)
            
        print("*Clem gives you a high five*")
                                                    

    def _return_to_neutral_positon(self):
        """Return arms' x, y and z coordinates to 0."""

        super()._return_to_neutral_positon()


    def listening_gesture(self, current_robot_emotion):
        """Unused inherited abstract method"""

        return super().listening_gesture(current_robot_emotion)                
        


class Hands(BodyParts):
    """
    A subclass to represent the humanoid robot's Hands. 

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    hug(safe_robot_force_method, user_force): 
        Method to move the position of the hands along the y axis in 
        order to simulate a hugging action. Called by corresponding 
        Arms method. Calls PhysicalInteraction method to coordinate 
        force applied by HR.

    squeeze_hand(hands_squeeze_method, safe_robot_force_method,
        user_force):
        Method to move the position of the arms along the y axis in 
        order to simulate a hand squeeze action. Called by 
        corresponding Arms method. Calls PhysicalInteraction method 
        to coordinate force applied by HR.

    shake_hand(hands_shake_method, safe_robot_force_method, 
        user_force):
        Method to move the position of the arms along the y axis in 
        order to simulate a hand shake action. Called by 
        corresponding Arms method. Calls PhysicalInteraction method 
        to coordinate force applied by HR.

    give_high_five(hands_hfive_method, safe_robot_force_method,
        user_force):
        Method to move the position of the hands along the x and 
        z axes in order to simulate a high-five action.
        Called by corresponding Arms method. Calls 
        PhysicalInteraction method to coordinate force applied by HR.

    """

    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """


    def hug(self, safe_robot_force_method, user_force):
        """
        Called by arms method, move the y position to give user a hug.

        Args:            
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """
        
        self.current_yposition -= 15
        safe_robot_force_method(user_force)


    def squeeze_hand(self, safe_robot_force_method, user_force):
        """
        Called by arms method, move the y position to squeeze hand.

        Args:            
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """

        self.current_yposition -= 20
        safe_robot_force_method(user_force)


    def shake_hand(self, safe_robot_force_method, user_force):
        """
        Called by arms method, move the y position to shake user's hand.

        Args:            
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """

        self.current_yposition -= 25
        safe_robot_force_method(user_force)


    def give_high_five(self, safe_robot_force_method, user_force):
        """
        Called by arms method, move x & z position to give high-five.

        Args:            
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """

        self.current_xposition += 10
        self.current_zposition += 10
        safe_robot_force_method(user_force)


    def _return_to_neutral_positon(self):
        """Return hands' x, y and z coordinates to 0."""

        super()._return_to_neutral_positon()


    def listening_gesture(self, current_robot_emotion):
        """Unused inherited abstract method"""

        return super().listening_gesture(current_robot_emotion)


class Torso(BodyParts):
    """
    A subclass to represent the humanoid robot's Torso. 

    Attributes
    ----------
    current_xposition : int
        The  body parts x axis spatial position.
    current_yposition : int
        The  body parts y axis spatial position.
    current_zposition : int
        The  body parts z axis spatial position.

    Methods
    -------
    listening_gesture(current_robot_emotion): 
        Method to show that the HR is listening, implementing a 
        nuanced lean that moves the z axis position of the bodypart.
    
    hug(safe_robot_force_method, user_force): 
        Method to move the position of the torso along the z axis in 
        order to simulate a hugging action. Calls PhysicalInteraction 
        method to coordinate force applied by HR.

    big_hug(safe_robot_force_method, user_force): 
        Method to move the position of the torso along the z axis in 
        order to simulate a more intense hugging action. Calls 
        PhysicalInteraction method to coordinate force applied by HR.

    """

    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        current_xposition : int
            The  body parts x axis spatial position.
        current_yposition : int
            The  body parts y axis spatial position.
        current_zposition : int
            The  body parts z axis spatial position.

        """    


    def listening_gesture(self, current_robot_emotion):
        """
        Move torso to lean, signify listening, expressing emotion.
        
        Args:
            current_robot_emotion (str): graded emotion calculated
            from robot class in response to user's emotion reading.

        Return: None  

        """                        

        c_r_e = current_robot_emotion

        if c_r_e == "pleased_1": 
            
            self.current_zposition -= 5                                         
                
            print("*Clem leans backwards a little*")

        elif c_r_e == "pleased_2" or c_r_e == "pleased_3": 
            
            self.current_zposition -= 10                                                   
                
            print("*Clem leans backwards*")
        
        elif c_r_e == "sympathetic_1":

            self.current_zposition += 5                                                   
                
            print("*Clem leans in slightly*")

        elif c_r_e == "sympathetic_2" or c_r_e == "sympathetic_3":

            self.current_zposition += 10                                                   
                
            print("*Clem leans in*")

        else: 
            pass # Do nothing if neutral emotion displayed.         
                            
    
    def big_hug(self, safe_robot_force_method, 
                user_force):
        """
        Move z position to give user a big hug.

        Args:            
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """

                
        self.current_zposition += 20
        safe_robot_force_method(user_force)


    def hug(self, safe_robot_force_method, 
                user_force):
        """
        Move z position to give user a big hug.

        Args:            
            safe_robot_force_method (str): name of method that 
            calculates how much force HR should apply, using user_force
            as argument.
            user_force (int): force applied by user, used as argument
            in safe_robot_force_method.

        Return:
            None         

        """        

        self.current_zposition += 15
        safe_robot_force_method(user_force)
        

    def _return_to_neutral_positon(self):
        """Return torso's x, y and z coordinates to 0."""

        super()._return_to_neutral_positon()


class PhysicalInteraction:     
    """A class to represent the humanoid robot's physical 
    interactions with the user. 

    Methods
    -------
    apply_safe_robot_force(user_force):
        Informs physically interacting body parts how much pressure
        to safely apply to user, based on force applied by user. 

    """

    def apply_safe_robot_force(self, user_force):
        """
        Calculate how much force to apply from hands, arms or torso
        
        Args:                        
            user_force (int): force applied by user.

        Return:
            robot_force (int): force that can be safely applied by HR.

        """        
        
        self.robot_force = 100 - user_force                

        return self.robot_force    


class RobotEmotion:
    """
    A class to represent the humanoid robot's physical 
    interactions with the user. 

    Methods
    -------
    decide_robot_emotion(current_user_emotion_rating):
        Returns an emotion as appropriate response to user's emotion
        reading.

    suggest_physical_interaction(current_user_emotion_rating):
        Suggests an appropriate physical interaction that can then be
        used to call the appropriate body part interaction methods 
        e.g. hug(). 

    """

    def decide_robot_emotion(self, current_user_emotion_rating):
        """
        Robot counter emotion decided based on user emotion rating.
        
        Args:
            current_user_emotion_rating (int): value assigned to user's
            emotion reading, denoting intensity of positivity or 
            negativity. 

        Return: 
            str: a string representing the robot's counter emotion: 
                - "sympathetic_3" if current_user_emotion_rating <= -3 
                - "sympathetic_2" if current_user_emotion_rating == -2 
                - "sympathetic_1" if current_user_emotion_rating == -1 
                - "neutral" if current_user_emotion_rating == 0 
                - "pleased_1" if current_user_emotion_rating == 1 
                - "pleased_2" if current_user_emotion_rating == 2 
                - "pleased_3" if current_user_emotion_rating >= 3

        """

        if current_user_emotion_rating <= -3: 
            return "sympathetic_3"
        elif current_user_emotion_rating == -2: 
            return "sympathetic_2"
        elif current_user_emotion_rating == -1: 
            return "sympathetic_1"
        elif current_user_emotion_rating == 0: 
            return "neutral"
        elif current_user_emotion_rating == 1: 
            return "pleased_1"
        elif current_user_emotion_rating == 2: 
            return "pleased_2"
        else:
            return "pleased_3"


    def suggest_physical_interaction(self, current_user_emotion_rating):
        """
        Suggest an appropriate physical interaction with user.

        Args:
            current_user_emotion_rating (integer): score relating to
            positive or negative emotion grade, to act as argument
            when calling self.decide_robot_emotion() method.

        Return: 
            str: a string suggesting a physical interaction:
                - "hug" if robot_emotion is "sympathetic_2" or 
                  "pleased_1"
                - "hand squeeze" if robot_emotion is "sympathetic_1"
                - "hand shake" if robot_emotion is "neutral"
                - "high five" if robot_emotion is "pleased_2"
                - "big hug" if robot_emotion is "sympathetic_3" or 
                  "pleased_3"

        """

        robot_emotion = self.decide_robot_emotion(current_user_emotion_rating)

        if robot_emotion == "sympathetic_2" or robot_emotion == "pleased_1":
            
            return "hug"

        elif robot_emotion == "sympathetic_1":
            
            return "hand squeeze"

        elif robot_emotion == "neutral":
            
            return "hand shake"

        elif robot_emotion == "pleased_2":
            
            return "high five"

        # Return "big hug" if current_robot_emotion is sympathetic_3 
        # or pleased_3. 
        else:

            return "big hug"   


class UserEmotion:
    """
    A class to represent the user's emotions. 

    Attributes
    ----------
    user_emotion_score_history : stack
        The  recorded mean emotion scores following each pair of 
        speech inputs.    
    user_emotion_choices : dictionary
        Categorised key emotion words to assist with identifying 
        intensity of user's emotions.   
    graded_emotions : list
        Used to hold graded emotions once converted i.e. negative_3, 
        negative_2, negative_1, neutral, positive_1, positive_2,
        positive_3. 
    emotions_scores : list
        Used to hold emotion score integers once graded emotions 
        converted. Scores correspond to intensity of emotion and can
        then be easily compared by methods. 
    
    Methods
    -------
    return_most_recent_user_emotion_grade():
        Finds and returns the last numerical value in the 
        user_emotion_score_history stack.

    """

    def __init__(self):        
        """
        Parameters
        ----------
        user_emotion_score_history : stack
            Stack of integers representing user's positive or 
            negative motion intensity.
        user_emotion_choices : dictionary
            Values categorised under keys that pertain to emotion's
            positive or negative motion intensity..
        graded_emotions : list
            List for temporary storage of emotions graded as being
            negative_3, negative_2, negative_1, neutral, positive_1,
            positive_2, or positive_3.
        emotions_scores: list
            List for temporary storage of emotions recorded for first
            speech set. Used to calulcate mean score before adding
            to user_emotion_score stack.

        """

        # A stack used to access most recent emotion.        
        self.user_emotion_score_history = [] 

        self.user_emotion_choices = {
                                "neutral": [
                                    "fine", 
                                    "OK", 
                                    "grand"
                                ],
                                "negative_1": [
                                    "melancholy", 
                                    "standoffish", 
                                    "put off", 
                                    "perturbed",
                                    "don't",
                                    "do not"                                                                        
                                ],
                                "negative_2": [
                                    "upset", 
                                    "anxious", 
                                    "annoyed", 
                                    "frustrated",
                                    "can't",
                                    "cannot"                                                                        
                                ], 
                                "negative_3": [
                                    "fearful", 
                                    "saddened", 
                                    "disgusted", 
                                    "angry",
                                    "depressed", 
                                    "lonely", 
                                    "alone",
                                    "nobody",
                                    "noone"
                                ],                                 
                                "positive_1": [
                                    "upbeat", 
                                    "good spirits", 
                                    "positive", 
                                    "better", 
                                    "thank", 
                                    "nice",
                                    "yes",
                                    "yeah"
                                ], 
                                "positive_2": [
                                    "excited", 
                                    "happy", 
                                    "pleased",
                                    "like",
                                    "hope"
                                ],
                                "positive_3": [
                                    "joyful", 
                                    "surprised", 
                                    "proud",
                                    "love"
                                ]   
                                }
        self.graded_emotions = []
        self.emotions_scores = []


    def return_most_recent_user_emotion_grade(self):
        """ 
        Return the top of the user_emotion_score_history stack.
        
        Return: 
            user_emotion_score_history[index_of_last_item] (int) -
            most recent score in user_emotion_score_history stack.        

        """

        index_of_last_item = len(self.user_emotion_score_history)-1

        return self.user_emotion_score_history[index_of_last_item] 
    

    def convert_emotion_string_to_graded_emotion(self, emotion):
        """
        Convert raw emotion string to a graded emotion string.

        Args:
            emotion_or_emotions (str): single emotion string e.g.
            'angry', 'frustrated'.

        Return: 
            str: a string key name that matches the value held:  
                negative_3 or negative_2 or negative_1 or neutral or 
                positive_1 or positive_2 or positive_3.
        
        """

        for key, value in self.user_emotion_choices.items():
            if emotion in value:
                return str(key)


    def _convert_emotion_list_to_graded_emotion_list(self, emotion_list):
        """Convert raw emotion list to a graded emotion string.

        Args:
            emotion_list (list): list of emotion strings e.g.
            ['angry', 'frustrated'].
        
        Return:
            list: graded_emotions - a list of string key names that 
            match the value held: negative_3 or negative_2 or negative_1 
            or neutral or positive_1 or positive_2 or positive_3. 

        """

        graded_emotions = []

        for emotion in emotion_list:
            for key, value in self.user_emotion_choices.items():
                if emotion in value:
                    graded_emotions.append(str(key))

        return graded_emotions

                                                
    def _convert_to_graded_emotions(self, semantic_emotion_matches, 
                                        user_facial_expression, 
                                        user_posture_sensor):
        '''
        Add record of graded positive or negative emotions sensed 
        
        Args:
            semantic_emotion_matches (list): list of emotion strings. 
            user_facial_expression (str): emotion string.
            user_posture_sensor (str): emotion string
        Return:
            None

            '''
        
        em_list = semantic_emotion_matches
        graded_emotions = self._convert_emotion_list_to_graded_emotion_list(em_list)
        
        for emotion in graded_emotions:
            self.graded_emotions.append(emotion)

        u_f_e = user_facial_expression
        u_f_e_graded_emotion = self.convert_emotion_string_to_graded_emotion(u_f_e)
        self.graded_emotions.append(u_f_e_graded_emotion)

        u_p_s = user_posture_sensor
        u_p_s_graded_emotion = self.convert_emotion_string_to_graded_emotion(u_p_s)
        self.graded_emotions.append(u_p_s_graded_emotion)
           

    def _convert_nonpitch_emotions_to_graded_emotion_scores(self):
        """Assign a numerical value to graded emotion reading."""
                
        for pos_or_neg_word in self.graded_emotions:
            if pos_or_neg_word == "positive_1":
                self.emotions_scores.append(1)
            elif pos_or_neg_word == "positive_2":
                self.emotions_scores.append(2)
            elif pos_or_neg_word == "positive_3":
                self.emotions_scores.append(3)
            elif pos_or_neg_word == "negative_1":
                self.emotions_scores.append(-1)
            elif pos_or_neg_word == "negative_2":
                self.emotions_scores.append(-2)
            elif pos_or_neg_word == "negative_3":
                self.emotions_scores.append(-3)
            else:
                self.emotions_scores.append(0) # Condition if neutral emotion.


    def calculate_median_user_emotion_score(self):
        """Calculate median user emotion rating from list of scores."""
        
        index_of_last_item = len(self.emotions_scores)-1
        sorted_score = sorted(self.emotions_scores)
        
        # Calculation if odd number of records.
        if len(sorted_score) % 2 != 0:            
            halfway_index = index_of_last_item // 2 
            median = sorted_score[halfway_index] 
        else:
            # Calculation if even number of records.
            over_hway = index_of_last_item // 2
            under_hway = over_hway - 1
            num_to_divide = sorted_score[over_hway] + sorted_score[under_hway]
            median = num_to_divide // 2 

        return median


    def _convert_pitch_emotions_to_graded_emotion_scores(self, baseline_pitch, user_voice_pitch):
        """Multiply median emotion score according to pitch reading."""
        
        median_rating = self.calculate_median_user_emotion_score()
                
        if baseline_pitch == "low":
            if user_voice_pitch <= 85 and user_voice_pitch < 110:
               pitch_emotion_rating = median_rating * 1

            elif user_voice_pitch <= 110 and user_voice_pitch < 135:
                pitch_emotion_rating = median_rating * 2
            
            elif user_voice_pitch <= 135 and user_voice_pitch < 160:
                pitch_emotion_rating = median_rating * 3

            else: 
                pitch_emotion_rating = median_rating * 4

        # Calculation if baseline assessment showed user as having naturally
        # high-pitched voice.
        else:
            if  user_voice_pitch <= 180:
                pitch_emotion_rating = median_rating * 1

            elif user_voice_pitch <= 205:
                pitch_emotion_rating = median_rating * 2
            
            elif user_voice_pitch <= 230:
                pitch_emotion_rating = median_rating * 3

            else: 
                pitch_emotion_rating = median_rating * 4
                            
        self.emotions_scores.append(pitch_emotion_rating)


    def calculate_mean_user_emotions_score(self):
        """Calculate mean score of all recorded emotion scores."""

        num_of_ratings = len(self.emotions_scores)
        
        total_emotion_rating = 0

        for rating in self.emotions_scores:
            
            total_emotion_rating += rating

        mean_emotion_rating = total_emotion_rating // num_of_ratings

        return mean_emotion_rating


    def _record_final_user_emotion_score(self, mean_emotion_rating):
        """Append final_user_emotion to user_emotion_score_history list."""

        self.user_emotion_score_history.append(mean_emotion_rating)


    def _reset_graded_emotions(self):
        """Reset grade_emotions, ready for next emotion analysis."""
        
        self.graded_emotions = []

    def _reset_emotions_scores(self):
        """Resets emotion_scores, ready for next emotion analysis."""
        
        self.emotions_scores = []
    

class SemanticSearch:
    
    """
    A class to represent the analysis of the user's speech. 

    Attributes
    ----------
    emotions_to_match : list
        Emotions to search for within the user's speech.     

    """

    def __init__(self):
        """
        Parameters
        ----------
        emotions_to_match : list
            List of emotions to search for and match against in 
            _emotions_match method.

        """
        
        self.emotions_to_match = [
            "fine", "grand", "melancholy", "standoffish", "put off",
            "perturbed", "upset", "anxious", "annoyed", "frustrated", 
            "fearful", "saddened", "disgusted", "angry", "don't",
            "depressed", "lonely", "alone", "nobody","noone", "upbeat", 
            "good spirits", "positive", "better", "thank", "nice", "excited",
            "happy", "pleased", "joyful", "surprised", "proud", "yes", "yeah", 
            "cannot", "do not", "love", "like", "hope"
        ]  
        

    def _emotions_match(self, user_message_list):
        """
        Use a difflib search method for close match to emotions.
        
        Args: 
            user_message_list (list): user's speech input in list 
            format.
        
        Return:
            list of emotion strings.
        
        """
        
        matches = []

        # If no matches, return a neutral emotion.
        if len(user_message_list) == 0:
            return ["fine"]

        # Search user's inputted speech, compare to words in 
        # emotions_to_match list and, when there is a close 
        # match, add to matches list.  
        for word in user_message_list:            
            
            closest_match = difflib.get_close_matches(word, self.emotions_to_match, n=1)
            
            if closest_match:
                
                matches.append(closest_match)

        # Ensure list of elements returned rather than list of single
        # element lists.
        return [item for match in matches for item in match] 
        
       
class ExpressionSensor:
    """
    A class to represent a sensor that reads the emotion on the 
    user's face. 

    Attributes
    ----------
    emotions_to_match : list
        Emotions to look out for when analysing the user's facial
        expressions.    
    emotions_final_index : int
        Final index value, to be used by random_index attribute to
        ensure random number given spans whole of emotions_to_match
        list index.   
    random_index : int
        Random number given that spans whole of emotions_to_match 
        list index.   

    """

    def __init__(self):
        """
        Parameters
        ----------
        emotions_to_match : list
            Emotions to look out for when analysing the user's facial
            expressions.
        emotions_final_index : int
            Final index value, to be used by random_index attribute to
            ensure random number given spans whole of emotions_to_match
            list index.   
        random_index : int
            Random number given that spans whole of emotions_to_match 
            list index.
            
        """
        
        self.emotions_to_match = [
            "fine", "melancholy", "standoffish", "put off", "perturbed", 
            "upset", "anxious", "annoyed", "frustrated", "fearful", "saddened", 
            "disgusted", "angry", "depressed", "lonely", "alone", "upbeat", 
            "good spirits", "positive", "excited", "happy", "pleased", 
            "joyful", "surprised", "proud", "hope"
        ]  

        self.emotions_final_index = len(self.emotions_to_match) -1
        self.random_index = random.randint(0, self.emotions_final_index)


    def _sense_facial_expression(self):
        """Simulate expression recognition by returning random emotion."""

        return self.emotions_to_match[self.random_index]


class PostureSensor(ExpressionSensor):
    """
    A class to represent a sensor that reads the emotion based on the 
    user's posture. 

    Attributes
    ----------
    emotions_to_match : list
        Emotions to look out for when analysing the user's facial
        expressions.    
    emotions_final_index : int
        Final index value, to be used by random_index attribute to
        ensure random number given spans whole of emotions_to_match
        list index.   
    random_index : int
        Random number given that spans whole of emotions_to_match 
        list index.   

    """

    def __init__(self):
        super().__init__()
        """
        Parameters
        ----------
        emotions_to_match : list
            Emotions to look out for when analysing the user's facial
            expressions.    
        emotions_final_index : int
            Final index value, to be used by random_index attribute to
            ensure random number given spans whole of emotions_to_match
            list index.   
        random_index : int
            Random number given that spans whole of emotions_to_match 
            list index.   
            
        """
    
    def _match_posture_to_emotion(self):
        '''Simulate posture recognition by returning random emotion.'''

        return self.emotions_to_match[self.random_index]

    
class PitchSensor:
    """
    A class to represent a sensor that reads the emotion based on the 
    user's posture. 

    Attributes
    ----------
    emotions_to_match : list
        Emotions to look out for when analysing the user's facial
        expressions.    
    emotions_final_index : int
        Final index value, to be used by random_index attribute to
        ensure random number given spans whole of emotions_to_match
        list index.   
    random_index : int
        Random number given that spans whole of emotions_to_match 
        list index.   

    """

    def _baseline_assess_natural_pitch(self, natural_pitch):
        """Simulate baseline assessment of natural pitch of user's voice."""

        if natural_pitch < 165:
            return "low"

        else:
            return "high"  


    def _assess_pitch(self, pitch_baseline_assessment):
        """Simulated reading of pitch, based on baseline assessment."""

        if pitch_baseline_assessment == "low":
            return random.randint(85, 185)

        else:
            return random.randint(155, 255)


class Dialogue:
    """
    A class to represent the HR's dialogue. 

    Attributes
    ----------
    chat_log_history : dictionary
        Formatted speech showing role and content, ready to pass to 
        ChatGPT API.    
    messages_to_reply_to : string
        Concatenated string of first and second user speech inputs.          
    
    """


    def __init__(self, chat_log_history, messages_to_reply_to=[]):
        """
        Parameters
        ----------
        chat_log_history : dictionary
            Formatted speech showing role and content, ready to pass to 
            ChatGPT API.    
        messages_to_reply_to : string
            Concatenated string of first and second user speech inputs.   
            
        """

        self.chat_log_history = chat_log_history
        self.messages_to_reply_to = messages_to_reply_to        
        

    def respond(self, new_chat_log):
        """
        Make calls to Chat GPT API with dialogue record.
        
        Args:
            new_chat_log (dictionary): key value pairs of 
            "role": "user", "content": speech used to format user's
            input, ready to pass to ChatGPT API.

        Return:
            str: formatted replay from ChatGPT.

        """                
        # Ensure that content inputted is in string format.
        user_input_str = str(new_chat_log["content"])

        # Update chat_log history.
        self.chat_log_history.append(new_chat_log)

        # system_content gives brief of Clem's role to keep tone 
        # consistent.   
        system_content = (
            "You are a caring social assistant who listens to elderly people" 
            " and responds so that they feel heard and understood. You may" 
            " give advice occasionally."
        )

        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_content},
                *self.chat_log_history, # Unpack chat_log_history.
                {"role": "user", "content": user_input_str}
            ]
        )        

        clem_response = response.choices[0].message.content
        
        formatted_clem_response = clem_response.strip("\n").strip()

        self.chat_log_history.append(
            {"role": "assistant", 
             "content": formatted_clem_response}
        )
        
        return formatted_clem_response



    def _say_goodbye(self, first_user_emotion_score, final_user_emotion_score):
        """
        Return a goodbye message, commenting on user's emotional journey. 

        Args:
            first_user_emotion_score (int): first emotion score 
            reading.

            final_user_emotion_score (int): final emotion score 
            reading.

        Return:
            str: message dending on emotion score difference.
        
        """

        # Outputted speech options based on change read from first
        # and final user emotion score.
        pos_msg = ("I'm glad that you seem to be feeling more positive since" 
                  " the start of our chat. I hope that I can continue to have" 
                  " a positive impact on your mood!")
        
        no_change_pos = ("I'm glad that you seem to have maintained a positive"
                        " outlook during our chat. Please know that this is a" 
                        " safe space to talk about negative emotions, should you" 
                        " wish to  during our next chat.")

        no_change_neg = ("I'm sorry that I don't appear to have improved your"
                        " mood. I hope I can have a more positive influence in our"
                        " next chat.")
        
        neg_msg = ("I'm sorry that you seem to be feeling less positive about" 
                    " things since the start of our conversation. I hope I can" 
                    " make you feel better the next time we chat.")
                
        # Reflect on user's emotional score readings, comparing first
        # and last and returning corresponding HR message from above
        # options.
        if first_user_emotion_score < final_user_emotion_score:
            return pos_msg

        elif first_user_emotion_score > final_user_emotion_score:
            return neg_msg

        # Condition if no change but final score is positive.
        elif final_user_emotion_score > 0:
            return no_change_pos

        # Condition if no change but final score is netural or negative.
        else:
            return no_change_neg


    def _user_confirms_choice(self, user_choice):
        """
        Return True if user enters 'y', False if user enters other key.         

        Args:
            user_choice (str): 'y' or any other key.

        Return: 
            Boolean.

        """
        
        if user_choice.lower() == "y":                    
            
            return True
                
        return False
                                           

    def _user_wants_to_say_goodbye(self, user_choice):                         
        """
        Return True if user enters 'g', False if user enters other key.         

        Args:
            user_choice (str): 'g' or any other key.

        Return: 
            Boolean.

        """

        if user_choice.lower() == "g":
            
            return True
        
        return False


    def _print_end_of_speech_prompt(self): 
        """Prompt user to check if they are at end of speech input."""

        prompts = [
            "\nAnything else on your mind?\n",
            "\nWould you like to add anything else?\n", 
            "\nDo you want to tell me more about that?\n"
        ]
        
        random_reply_index = random.randint(0, len(prompts) - 1)

        options = (
            "\n*Type 'y' to add more,'g' to say goodbye or any other key to" 
            " get a response.*\n"
        )

        print(prompts[random_reply_index],options)
                            

