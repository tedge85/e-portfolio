import unittest
from clem import (
    PitchSensor, 
    PostureSensor, 
    ExpressionSensor, 
    RobotEmotion, 
    SemanticSearch, 
    UserEmotion, 
    Dialogue
)


class SemanticSearchTests(unittest.TestCase):
    """Test SemanticSearch.emotions_match()."""

    def setUp(self):
        
        self.semantic_search = SemanticSearch()        


    def test__emotions_match_with_values(self):
        """Test to see if matches and near matches function correctly."""
        
        input_list = ["snow", "fine", "exciting", "angry", "joy", "rubbish", "angered",
                       "potato"]
        
        output = ["fine", "excited", "angry", "joyful", "angry"]

        self.assertEqual(self.semantic_search._emotions_match(input_list), output)
    

    def test__emotions_match_without_values(self):
        """Test to see if no match returns the expected default “fine”."""

        self.assertEqual(self.semantic_search._emotions_match([]), ["fine"])


class ExpressionSensorTests(unittest.TestCase):
    """Test ExpressionSensor._sense_facial_expression()."""

    def setUp(self):
        self.expression_sensor = ExpressionSensor()


    def test__sense_facial_expression(self):
        """Test to see if calling it returns a string that is in 
        ExpressionSensor.emotions_to_match() list."""

        test_method = self.expression_sensor._sense_facial_expression()

        
        self.assertIn(test_method, self.expression_sensor.emotions_to_match)


class PostureSensorTests(unittest.TestCase):
    """Test PostureSensor._match_posture_to_emotion.()"""

    def setUp(self):
        self.posture_sensor = PostureSensor()


    def test__match_posture_to_emotion(self):
        """Test to see if calling  _match_posture_to_emotion() returns
        a string that is in PostureSensor.emotions_to_match list"""

        test_method = self.posture_sensor._match_posture_to_emotion()

        
        self.assertIn(test_method, self.posture_sensor.emotions_to_match)


class PitchSensorTests(unittest.TestCase):
    """Test PitchSensor._baseline_assess_natural_pitch()."""

    def setUp(self):
        self.pitch_sensor = PitchSensor()        


    def test__baseline_assessment_extreme_low(self):
        """Test to see if low numerical value returns “low” string."""

        method = self.pitch_sensor._baseline_assess_natural_pitch(85)

        self.assertEqual(method, "low")

    
    def test__baseline_assessment_normal(self):
        """Test to see if mid numerical value returns “high” string."""

        method = self.pitch_sensor._baseline_assess_natural_pitch(165)

        self.assertEqual(method, "high")

    
    def test__baseline_assessment_extreme_high(self):
        """Test to see if high numerical value returns “high” string."""

        method = self.pitch_sensor._baseline_assess_natural_pitch(255)

        self.assertEqual(method, "high")


class FirstUserEmotionTests(unittest.TestCase):
    """Test 
    UserEmotion. _convert_nonpitch_emotions_to_graded_emotion_scores()."""

    def setUp(self):
         
        self.user_emotion = UserEmotion()

        ems = [
            "negative_3",
            "negative_2",
            "negative_1",
            "neutral",
            "positive_1",
            "positive_2", 
            "positive_3",
            "positive_3",
            "positive_3",
            "positive_3",
            "positive_3"
        ]

        self.user_emotion.graded_emotions = ems

        self.user_emotion._convert_nonpitch_emotions_to_graded_emotion_scores()
        

    def test__convert_nonpitch_emotions_to_graded_emotion_scores(self):
        """Test to see if calling 
        _convert_nonpitch_emotions_to_graded_emotion_scores converts 
        current graded emotions in UserEmotion.graded_emotions 
        correctly."""

        emotion_scores = self.user_emotion.emotions_scores      

        self.assertEqual(emotion_scores, [-3,-2,-1,0,1,2,3,3,3,3,3])
        

    def test_calculate_median_user_emotion_score_odd_num_entries(self):
        '''Test calculate_median_user_emotion_score() with odd number of
        entries in current_user_emotion_scores to see if it calculates
        median score correctly.'''
        
        method = self.user_emotion.calculate_median_user_emotion_score()

        self.assertEqual(method, 2)


    def test_convert_emotion_string_to_graded_emotion(self):    
        """Test convert_emotion_string_to_graded_emotion() to see if 
        string is matched to correct key."""
        
        user_em = self.user_emotion

        method = user_em.convert_emotion_string_to_graded_emotion("excited")

        self.assertEqual(method, "positive_2")


    def test__convert_emotion_list_to_graded_emotion_list_items(self):    
        """Test _convert_emotion_list_to_graded_emotion_list() to see if 
        list of strings is matched to correct key and outputted as a 
        list."""
        
        e_list = ["OK", "upset", "upbeat"]

        user_em = self.user_emotion

        method = user_em._convert_emotion_list_to_graded_emotion_list(e_list)

        self.assertEqual(method, ["neutral", "negative_2", "positive_1"])
    

    def test__convert_emotion_list_to_graded_emotion_list_single_item(self):    
        """Test _convert_emotion_list_to_graded_emotion_list() to see if 
        list of single element string is matched to correct key and 
        outputted as a list."""

        e_list = ["fine"]

        user_em = self.user_emotion

        method = user_em._convert_emotion_list_to_graded_emotion_list(e_list)

        self.assertEqual(method, ["neutral"])


    def test__convert_pitch_emotions_to_graded_emotion_scores(self):
        """Test _convert_pitch_emotions_to_graded_emotion_scores() to 
        see if given pitch reading converts to an appropriate score and 
        is appended to emotions_scores."""

        self.user_emotion._convert_pitch_emotions_to_graded_emotion_scores("high", 206)
        
        emotion_scores = self.user_emotion.emotions_scores      

        self.assertEqual(emotion_scores, [-3,-2,-1,0,1,2,3,3,3,3,3,6])    
    

class SecondUserEmotionTests(unittest.TestCase):
    """Test 
    UserEmotion. _convert_pitch_emotions_to_graded_emotion_scores()."""
    
    def setUp(self):
        
        self.user_em = UserEmotion()
        
        ems = [
            "positive_1",
            "positive_2",
            "neutral",
            "positive_3",
            "negative_2", 
            "positive_3",
            "neutral"
        ]
        
        self.user_em.graded_emotions = ems

        self.user_em._convert_nonpitch_emotions_to_graded_emotion_scores()

        self.user_em._convert_pitch_emotions_to_graded_emotion_scores("high", 180)    


    def test__convert_pitch_emotions_to_graded_emotion_scores(self):
        """Test _convert_pitch_emotions_to_graded_emotion_scores() to 
        see if given pitch reading converts to an appropriate score and
        is appended to emotions_scores."""

        user_em = self.user_em

        curr_emotion_ratings = user_em.emotions_scores

        expected_result = [1,2,0,3,-2,3,0,1]

        self.assertEqual(curr_emotion_ratings, expected_result)
    

    def test_calculate_mean_user_emotions_score(self):
        """Test calculate_mean_user_emotions_score() to see if it 
        correctly calculates mean average of scores."""

        method = self.user_em.calculate_mean_user_emotions_score()        

        self.assertEqual(method, 1)
    

    def test__convert_to_graded_emotions(self):
        """Test _convert_nonpitch_emotions_to_graded_emotion_scores()
        to see if the list of strings is read and corresponding scores 
        appended to emotions_scores list."""        

        user_em = self.user_em

        em_list = ["joyful","happy","upbeat"]
        em1 = "annoyed"
        em2 = "grand"        

        user_em._convert_to_graded_emotions(em_list,em1,em2)

        updates_to_list = [
            "positive_3",
            "positive_2",
            "positive_1",
            "negative_2",
            "neutral"
        ]

        previous_list = [            
            "positive_1",
            "positive_2",
            "neutral",
            "positive_3",
            "negative_2", 
            "positive_3",
            "neutral"
        ]

        expected_list = previous_list + updates_to_list
        
        stored_emotions = user_em.graded_emotions

        self.assertEqual(stored_emotions,expected_list)


    def test__record_final_user_emotion_score(self):
        """Test _record_final_user_emotion_score() to see if score 
        passed to method is appended to user_emotion_score_history 
        stack."""

        mean = self.user_em.calculate_mean_user_emotions_score()
        
        self.user_em._record_final_user_emotion_score(mean)

        emotion_history = self.user_em.user_emotion_score_history

        self.assertEqual(emotion_history, [1])


    def test__reset_graded_emotions(self):
        """Test _reset_graded_emotions() to see if current_emotions is
        reset to an empty list when called."""

        self.user_em._reset_graded_emotions()

        current_emotions = self.user_em.graded_emotions

        self.assertEqual(current_emotions, [])


    def test__reset_emotions_scores(self):
        """Test _reset_ emotions_scores() to see if 
        current_emotions_scores is reset to an empty list when called."""

        self.user_em._reset_emotions_scores()

        current_emotions_scores = self.user_em.emotions_scores

        self.assertEqual(current_emotions_scores, [])

    
class ThirdUserEmotionTests(unittest.TestCase):
    """Test 
    UserEmotion._calculate_median_user_emotion_score_even_num_entries
    and UserEmotion._return_most_recent_user_emotion_grade()."""

    def setUp(self):
        
        self.user_emotion = UserEmotion()

        self.user_emotion.user_emotion_score_history = [0,2,4,1,2,-1]
        
        self.user_emotion.emotions_scores = [3,2,3,2]
    

    def test_calculate_median_user_emotion_score_even_num_entries(self):
        """Test calculate_median_user_emotion_score() with an even 
        number of entries to see if it correctly calculates a median 
        average of the scores."""                

        method = self.user_emotion.calculate_median_user_emotion_score()

        self.assertEqual(method, 2)


    def test_return_most_recent_user_emotion_grade(self):
        """Test return_most_recent_user_emotion_grade() to see if final
        element in user_emotion_score_history is returned."""

        method = self.user_emotion.return_most_recent_user_emotion_grade()

        self.assertEqual(method, -1)
        

class RobotEmotionTest(unittest.TestCase):
    """Test RobotEmotion.decide_robot_emotion() and 
    suggest_physical_interaction."""

    def setUp(self):
        
        self.r_emotion = RobotEmotion()


    def test_decide_robot_emotion_extreme(self):
        """Test decide_robot_emotion() to see if passed extreme negative
        user emotion score is converted to the corresponding countering 
        robot emotions."""

        method = self.r_emotion.decide_robot_emotion(-5)

        self.assertEqual(method, "sympathetic_3")


    def test_decide_robot_emotion_normal(self):
        """Test decide_robot_emotion() to see if passed normal positive 
        user emotion score is converted to the corresponding countering 
        robot emotions."""

        method = self.r_emotion.decide_robot_emotion(2)

        self.assertEqual(method, "pleased_2")


    def test_suggest_physical_interaction_hug(self):
        """Test suggest_physical_interaction() to see if inputted score
        returns 'hug'."""

        method = self.r_emotion.suggest_physical_interaction(-2)

        self.assertEqual(method, "hug")


    def test_suggest_physical_interaction_squeeze_hand(self):
        """Test suggest_physical_interaction() to see if inputted score
        returns 'hand squeeze'."""

        method = self.r_emotion.suggest_physical_interaction(-1)

        self.assertEqual(method, "hand squeeze")


    def test_suggest_physical_interaction_shake_hand(self):
        """Test suggest_physical_interaction() to see if inputted score
        returns 'hand shake'."""

        method = self.r_emotion.suggest_physical_interaction(0)

        self.assertEqual(method, "hand shake")


    def test_suggest_physical_interaction_high_five(self):
        """Test suggest_physical_interaction() to see if inputted score
        returns 'high five'."""

        method = self.r_emotion.suggest_physical_interaction(2)

        self.assertEqual(method, "high five")


    def test_suggest_physical_interaction_big_hug(self):
        """Test suggest_physical_interaction() to see if inputted score
        returns 'big hug'."""

        method = self.r_emotion.suggest_physical_interaction(9)

        self.assertEqual(method, "big hug")


class DialogueTest(unittest.TestCase):
    """Test Dialogue._say_goodbye(), _user_confirms_choice(),
    and _user_wants_to_say_goodbye()."""

    def setUp(self):

        description_of_carer_role = (
            "You are a caring social assistant who listens to elderly people and" 
            " responds so that they feel heard and understood. You may give advice" 
            " occasionally."
        )

        self.dialogue = Dialogue(chat_log_history = [
                            {"role": "system",
                            "content": description_of_carer_role}
                            ])      

    def test_repond_normal(self):
        """Test Diaogue.respond() to see if ChatGPT API is called with 
        normal input."""

        speech = "I am pleased to meet you. Are you able to help me?"

        updated_chat_log = {
            "role": "user", 
            "content": speech 
        }

        try:
            self.dialogue.respond(updated_chat_log)

        except Exception as e:
            self.fail(f"dialogue.repond() raised {type(e).__name__}!")

    
    def test_repond_blank(self):
        """Test Diaogue.respond() to see if ChatGPT API is functions 
        despite no user input."""

        speech = ""

        updated_chat_log = {
            "role": "user", 
            "content": speech 
        }

        try:
            self.dialogue.respond(updated_chat_log)
        
        except Exception as e:
            self.fail(f"dialogue.repond() raised {type(e).__name__}!")
        

    def test_repond_int(self):
        """Test Diaogue.respond() to see if ChatGPT API functions with
        integer-only input."""

        speech = 12345678910

        updated_chat_log = {
            "role": "user", 
            "content": speech 
        }

        try:
            self.dialogue.respond(updated_chat_log)
        except Exception as e:
            self.fail(f"dialogue.repond() raised {type(e).__name__}!")


    def test__say_goodbye_pos(self):
        """Test _say_goodbye() to see if appropriate positive response 
        is given, based on reading of first and final user emotion score
        that shows a positive increase."""

        method = self.dialogue._say_goodbye(-1,3)

        msg = ("I'm glad that you seem to be feeling more positive since" 
                  " the start of our chat. I hope that I can continue to have" 
                  " a positive impact on your mood!")

        self.assertEqual(method, msg)

    
    def test__say_goodbye_neg(self):
        """Test _say_goodbye() to see if appropriate response is given, 
        based on reading of first and final user emotion score that 
        shows a decrease."""

        method = self.dialogue._say_goodbye(-1,-3)

        msg = ("I'm sorry that you seem to be feeling less positive about" 
                    " things since the start of our conversation. I hope I can" 
                    " make you feel better the next time we chat.")

        self.assertEqual(method, msg)


    def test__say_goodbye_no_change_pos(self):
        """Test _say_goodbye() to see if appropriate response is given, 
        based on reading of first and final user emotion score that 
        shows no change in score and both scores are positive integers."""

        method = self.dialogue._say_goodbye(2,2)

        msg = ("I'm glad that you seem to have maintained a positive"
                        " outlook during our chat. Please know that this is a" 
                        " safe space to talk about negative emotions, should you" 
                        " wish to  during our next chat.")

        self.assertEqual(method, msg)

    
    def test__say_goodbye_no_change_neg(self):
        """Test _say_goodbye() to see if appropriate response is given, 
        based on reading of first and final user emotion score that 
        shows no change in score and both scores are negative integers."""

        method = self.dialogue._say_goodbye(-2,-2)

        msg = ("I'm sorry that I don't appear to have improved your"
                        " mood. I hope I can have a more positive influence in our"
                        " next chat.")

        self.assertEqual(method, msg)

    
    def test__user_confirms_choice_true(self):
        """Test _user_confirms_choice() to see if capitalised ‘Y’ returns
        expected ‘True’."""

        choice = "Y"

        method = self.dialogue._user_confirms_choice(choice)

        self.assertEqual(method, True)

    
    def test__user_confirms_choice_false(self):
        """Test _user_confirms_choice() to see if key other than ‘Y/y’ 
        returns False."""

        choice = "F"

        method = self.dialogue._user_confirms_choice(choice)

        self.assertEqual(method, False)


    def test__user_wants_to_say_goodbye_true(self):
        """Test _user_wants_to_say_goodbye() to see if capitalised G 
        returns expected ‘True’."""
        
        choice = "G"

        method = self.dialogue._user_wants_to_say_goodbye(choice)

        self.assertEqual(method, True)

    
    def test__user_wants_to_say_goodbye_false(self):
        """Test _user_wants_to_say_goodbye() to see if key other than 
        ‘G/g’ returns expected ‘False’."""

        choice = "C"

        method = self.dialogue._user_wants_to_say_goodbye(choice)

        self.assertEqual(method, False)


unittest.main()